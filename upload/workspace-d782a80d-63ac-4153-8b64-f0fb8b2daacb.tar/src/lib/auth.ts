export function verifyAdmin(request: Request): boolean {
  const token = process.env.ADMIN_SECRET;
  if (!token) return false;
  const auth = request.headers.get('authorization');
  return auth === `Bearer ${token}`;
}
