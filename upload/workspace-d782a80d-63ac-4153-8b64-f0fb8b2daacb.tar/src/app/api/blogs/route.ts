import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyAdmin } from '@/lib/auth';

function generateSlug(title: string): string {
  return title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '');
}

// GET /api/blogs — PUBLIC, returns published posts (no content field)
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const published = searchParams.get('published');
    const limitParam = searchParams.get('limit');
    const category = searchParams.get('category');

    const limit = Math.min(Math.max(parseInt(limitParam || '6', 10) || 6, 1), 100);

    const where: Record<string, unknown> = {};
    if (published === null || published === 'true') {
      where.published = true;
    }
    if (category) {
      where.category = category;
    }

    const posts = await db.blogPost.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      select: {
        id: true,
        slug: true,
        title: true,
        excerpt: true,
        coverImage: true,
        category: true,
        author: true,
        published: true,
        createdAt: true,
        updatedAt: true,
      },
    });

    return NextResponse.json(posts);
  } catch (error) {
    console.error('Blogs fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch blogs' }, { status: 500 });
  }
}

// POST /api/blogs — ADMIN, creates a new blog post
export async function POST(request: NextRequest) {
  if (!verifyAdmin(request)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const body = await request.json();
    const { title, slug, excerpt, content, coverImage, category, author, published } = body;

    // Validation
    const errors: Record<string, string> = {};

    if (!title || typeof title !== 'string' || title.trim().length === 0) {
      errors.title = 'Title is required.';
    }

    const finalSlug = slug?.trim() ? slug.trim() : generateSlug(title);
    if (!/^[a-z0-9-]+$/.test(finalSlug)) {
      errors.slug = 'Slug must contain only lowercase letters, numbers, and hyphens.';
    }

    if (!content || typeof content !== 'string' || content.trim().length === 0) {
      errors.content = 'Content is required.';
    }

    if (Object.keys(errors).length > 0) {
      return NextResponse.json({ error: 'Validation failed', fields: errors }, { status: 400 });
    }

    // Check for existing slug
    const existing = await db.blogPost.findUnique({ where: { slug: finalSlug } });
    if (existing) {
      return NextResponse.json(
        { error: 'A post with this slug already exists.', fields: { slug: 'Slug must be unique.' } },
        { status: 409 }
      );
    }

    const post = await db.blogPost.create({
      data: {
        title: title.trim(),
        slug: finalSlug,
        content: content.trim(),
        excerpt: excerpt?.trim() || null,
        coverImage: coverImage || null,
        category: category?.trim() || 'General',
        author: author?.trim() || 'SYA Team',
        published: typeof published === 'boolean' ? published : false,
      },
    });

    return NextResponse.json(post, { status: 201 });
  } catch (error) {
    console.error('Blog creation error:', error);
    return NextResponse.json({ error: 'Failed to create blog post' }, { status: 500 });
  }
}
